# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['python_poetry']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.2,<2.0.0']

entry_points = \
{'console_scripts': ['my-script = python_poetry:main']}

setup_kwargs = {
    'name': 'python-poetry',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Ryas-Yusenda',
    'author_email': '44300598+Ryas-Yusenda@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
